#ifndef CONSTANTS_H
#define CONSTANTS_H

#define MAX_ENEMIES 8
//unsigned int level_address[]={0xC000,0xC4B4,0xC9DF};	// Level addresses
//unsigned int enemy_address[]={0xC44B,0xC976,0xCE66};        // Enemy addresses

//ATTENTION - Hard coded addresses
//unsigned int level_address[]={0xC000,0xC6C7,0xCBF2,0xD0E2,0xD0E2,0xD0E2,0xD0E2};	// Level addresses
//unsigned int enemy_address[]={0xC65E,0xCB89,0xD079};        // Enemy addresses

// WYZ player addresses

//#define CARGA_CANCION 	0xC063
//check compiled.map in RAM0
//_CARGA_CANCION

//#define WYZ_PLAY	0xC03F
// It is INICIO in the wyzplayer sym file
//_INICIO

//#define STOP_PLAYER	0xC365

#endif
