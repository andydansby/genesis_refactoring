#ifndef RAMMAIN_H
#define RAMMAIN_H


void borderTester (void)
{
	while(1){
		zx_border(0);zx_border(5);
	}
}

#endif
