#ifndef RAM0_H
#define RAM0_H

// located in bank 0
extern unsigned char screen0[];
extern void __FASTCALL__ blackout2();

#endif