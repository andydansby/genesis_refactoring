#ifndef RAM6_H
#define RAM6_H

// located in bank 6
extern unsigned char screen3[];
extern unsigned char screen4[];
extern unsigned char screen5[];
extern unsigned char screen6[];

extern void __FASTCALL__ blackout1();

#endif
