#ifndef DISPLAYLOOP_H
#define DISPLAYLOOP_H

extern void display_loop (void);


#endif